.. _advanced:

Advanced Options
================

Here we will present some more advanced examples

.. toctree::
   :glob:

   advanced/*