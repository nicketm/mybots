.. _videos:

Videos
======

**Pyrosim in action**

The following videos are an assortment of independent 
projects in evolutionary robotics.

|
|

Billiards Bot
-------------

.. raw:: html

    <iframe width="100%" height="315" src="https://www.youtube.com/embed/V5dqJmJhOms?start=112" frameborder="0" allowfullscreen></iframe>

|
|

Pitch Bot
---------

.. raw:: html

    <iframe width="100%" height="315" src="https://www.youtube.com/embed/pntpHbZQYrw?start=140" frameborder="0" allowfullscreen></iframe>